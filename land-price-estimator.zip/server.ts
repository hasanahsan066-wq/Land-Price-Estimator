import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { LandInputs, ValuationResult, SavedEstimate } from './src/types';
import { calculateInstantValuation, USD_TO_PKR_RATE } from './src/utils/valuationEngine';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// File-backed persistence for 15-day valuation history database
const DATA_DIR = path.join(process.cwd(), 'data');
const VALUATIONS_FILE = path.join(DATA_DIR, 'valuations.json');

function ensureDataFileExists() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(VALUATIONS_FILE)) {
    fs.writeFileSync(VALUATIONS_FILE, JSON.stringify([], null, 2), 'utf-8');
  }
}

// 15 days in milliseconds
const FIFTEEN_DAYS_MS = 15 * 24 * 60 * 60 * 1000;

function readValuationsFromDb(): SavedEstimate[] {
  ensureDataFileExists();
  try {
    const raw = fs.readFileSync(VALUATIONS_FILE, 'utf-8');
    const records: SavedEstimate[] = JSON.parse(raw || '[]');
    const now = Date.now();
    
    // Purge records older than 15 days automatically
    const valid15DayRecords = records.filter(r => {
      const createdTime = new Date(r.createdAt).getTime();
      return (now - createdTime) <= FIFTEEN_DAYS_MS;
    });

    if (valid15DayRecords.length !== records.length) {
      fs.writeFileSync(VALUATIONS_FILE, JSON.stringify(valid15DayRecords, null, 2), 'utf-8');
    }

    return valid15DayRecords;
  } catch (err) {
    console.error('Error reading valuations database:', err);
    return [];
  }
}

function saveValuationsToDb(records: SavedEstimate[]) {
  ensureDataFileExists();
  const now = Date.now();
  const valid15DayRecords = records.filter(r => {
    const createdTime = new Date(r.createdAt).getTime();
    return (now - createdTime) <= FIFTEEN_DAYS_MS;
  });
  fs.writeFileSync(VALUATIONS_FILE, JSON.stringify(valid15DayRecords, null, 2), 'utf-8');
}

// Shared Gemini Client
function getGeminiAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check route
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// GET /api/valuations - Retrieve recent valuations from last 15 days
app.get('/api/valuations', (_req, res) => {
  try {
    const history = readValuationsFromDb();
    res.json({ success: true, count: history.length, data: history });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/valuations - Save a new valuation to the 15-day database
app.post('/api/valuations', (req, res) => {
  try {
    const { inputs, result, title, currency } = req.body;
    if (!inputs || !result) {
      return res.status(400).json({ success: false, error: 'Inputs and result required' });
    }

    const newRecord: SavedEstimate = {
      id: `val_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      title: title || `${inputs.locationName || 'Land Parcel'} (${inputs.size} ${inputs.unit})`,
      createdAt: new Date().toISOString(),
      inputs,
      result,
      currency: currency || 'PKR'
    };

    const currentRecords = readValuationsFromDb();
    const updated = [newRecord, ...currentRecords];
    saveValuationsToDb(updated);

    res.json({ success: true, data: newRecord });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/valuations/:id - Remove a valuation record
app.delete('/api/valuations/:id', (req, res) => {
  try {
    const { id } = req.params;
    const currentRecords = readValuationsFromDb();
    const filtered = currentRecords.filter(r => r.id !== id);
    saveValuationsToDb(filtered);
    res.json({ success: true, remainingCount: filtered.length });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/valuations - Clear all records
app.delete('/api/valuations', (_req, res) => {
  try {
    saveValuationsToDb([]);
    res.json({ success: true, message: 'Cleared all historical valuation records.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Main AI Land Price Estimator Endpoint
app.post('/api/estimate-land', async (req, res) => {
  try {
    const inputs: LandInputs = req.body;
    
    // 1. Calculate instant baseline mathematical appraisal
    const baselineResult = calculateInstantValuation(inputs);

    const ai = getGeminiAI();
    if (!ai) {
      // Return baseline mathematical result smoothly
      return res.json({
        success: true,
        data: baselineResult,
        aiEnriched: false,
        message: 'Calculated using real estate valuation engine.'
      });
    }

    // 2. Call Gemini for deep market comparative analysis & appraisal insights
    const prompt = `You are a certified senior master real estate land appraiser and geospatial analyst specializing in South Asian (Pakistani) and international real estate markets.
Perform a comprehensive property land valuation appraisal for the following parcel:

- Location: ${inputs.locationName} (Lat: ${inputs.lat || 'N/A'}, Lng: ${inputs.lng || 'N/A'})
- Size: ${inputs.size} ${inputs.unit}
- Property Type: ${inputs.propertyType}
- Zoning: ${inputs.zoning}
- Topography: ${inputs.topography}
- Road Access: ${inputs.roadAccess}
- Lot Shape: ${inputs.lotShape}
- Soil Quality: ${inputs.soilQuality}
- Infrastructure / Utilities:
  - Electricity: ${inputs.hasElectricity ? 'Connected' : 'None'}
  - Water: ${inputs.hasWater ? 'Connected' : 'None'}
  - Sewer: ${inputs.hasSewer ? 'Connected' : 'None'}
  - High-Speed Internet: ${inputs.hasInternet ? 'Available' : 'None'}
- Distance to City Center: ${inputs.distanceToCityMiles} miles
- Market Trend: ${inputs.marketTrend}
- Subdivision Potential: ${inputs.subdivisionPotential ? 'Yes' : 'No'}
- Waterfront: ${inputs.hasWaterfront ? 'Yes' : 'No'}
- Flood Zone: ${inputs.floodZone ? 'Yes' : 'No'}
- Additional Notes: ${inputs.additionalNotes || 'None'}

Mathematical Baseline Midpoint Estimate: $${baselineResult.estimatedValue.toLocaleString()} USD (~Rs. ${baselineResult.estimatedValuePKR?.toLocaleString()} PKR)

Generate a refined appraisal in valid JSON matching the exact schema:
1. Provide realistic market value range (low, high, estimatedValue in USD).
2. Provide 3 realistic comparable recent land sales in that specific area (e.g., DHA, Bahria, Gulberg, Sector F-6, Clifton, etc. if in Pakistan).
3. Provide 2-3 development or investment strategies with feasibility and ROI description.
4. Risk factors and mitigation steps.
5. Executive AI Summary appraisal report (2-3 paragraphs, professional appraiser tone).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            estimatedValue: { type: Type.NUMBER, description: 'Refined mid-market estimate in USD' },
            lowValue: { type: Type.NUMBER, description: 'Conservative valuation bound in USD' },
            highValue: { type: Type.NUMBER, description: 'Optimistic/premium valuation bound in USD' },
            pricePerAcre: { type: Type.NUMBER, description: 'Refined per-acre valuation in USD' },
            valuationScore: { type: Type.NUMBER, description: 'Overall land investment rating score 0-100' },
            buildabilityIndex: { type: Type.NUMBER, description: 'Ease of construction rating 0-100' },
            investmentGrade: { type: Type.STRING, description: 'Grade like A+, A, B+, B, C' },
            aiSummary: { type: Type.STRING, description: 'Detailed executive appraisal narrative' },
            comparableSales: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  property: { type: Type.STRING },
                  distance: { type: Type.STRING },
                  size: { type: Type.STRING },
                  salePrice: { type: Type.STRING },
                  pricePerAcre: { type: Type.STRING },
                  similarity: { type: Type.STRING }
                },
                required: ['property', 'distance', 'size', 'salePrice', 'pricePerAcre', 'similarity']
              }
            },
            developmentPotentials: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  strategy: { type: Type.STRING },
                  feasibility: { type: Type.STRING },
                  estimatedUpside: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ['strategy', 'feasibility', 'estimatedUpside', 'description']
              }
            },
            riskFactors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  factor: { type: Type.STRING },
                  severity: { type: Type.STRING },
                  mitigation: { type: Type.STRING }
                },
                required: ['factor', 'severity', 'mitigation']
              }
            }
          },
          required: [
            'estimatedValue',
            'lowValue',
            'highValue',
            'pricePerAcre',
            'valuationScore',
            'buildabilityIndex',
            'investmentGrade',
            'aiSummary',
            'comparableSales',
            'developmentPotentials',
            'riskFactors'
          ]
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');

    const estUSD = parsed.estimatedValue || baselineResult.estimatedValue;
    const estPKR = Math.round(estUSD * USD_TO_PKR_RATE);

    // Merge baseline structure with AI insights
    const enrichedResult: ValuationResult = {
      ...baselineResult,
      estimatedValue: estUSD,
      estimatedValuePKR: estPKR,
      valueRange: {
        low: parsed.lowValue || baselineResult.valueRange.low,
        high: parsed.highValue || baselineResult.valueRange.high,
      },
      pricePerUnit: {
        ...baselineResult.pricePerUnit,
        pricePerAcre: parsed.pricePerAcre || baselineResult.pricePerUnit.pricePerAcre,
      },
      valuationScore: parsed.valuationScore || baselineResult.valuationScore,
      buildabilityIndex: parsed.buildabilityIndex || baselineResult.buildabilityIndex,
      investmentGrade: parsed.investmentGrade || baselineResult.investmentGrade,
      aiSummary: parsed.aiSummary || baselineResult.aiSummary,
      comparableSales: parsed.comparableSales && parsed.comparableSales.length > 0 ? parsed.comparableSales : baselineResult.comparableSales,
      developmentPotentials: parsed.developmentPotentials && parsed.developmentPotentials.length > 0 ? parsed.developmentPotentials : baselineResult.developmentPotentials,
      riskFactors: parsed.riskFactors && parsed.riskFactors.length > 0 ? parsed.riskFactors : baselineResult.riskFactors,
    };

    return res.json({
      success: true,
      data: enrichedResult,
      aiEnriched: true
    });

  } catch (err: any) {
    console.error('Error in /api/estimate-land:', err);
    // Graceful fallback to baseline calculation if AI error
    const baselineResult = calculateInstantValuation(req.body);
    return res.json({
      success: true,
      data: baselineResult,
      aiEnriched: false,
      error: err.message || 'AI service unavailable, using mathematical baseline model.'
    });
  }
});

// AI Land Advisor Chat Endpoint
app.post('/api/land-advisor', async (req, res) => {
  try {
    const { prompt, landContext } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGeminiAI();
    if (!ai) {
      return res.json({
        reply: 'Gemini AI key is not configured. Please add GEMINI_API_KEY in Settings > Secrets to unlock AI land appraisal assistance.'
      });
    }

    let systemContext = `You are "TerraVal AI", an expert real estate land valuation and land development consultant specialized in both Pakistani (Kanal, Marla, PKR) and Global real estate markets.
Provide clear, actionable, professional answers regarding property estimation, zoning regulations, soil testing, road building costs, subdivision feasibility, and land investment metrics.`;

    if (landContext) {
      systemContext += `\nCurrently analyzed land context:
- Location: ${landContext.locationName}
- Size: ${landContext.size} ${landContext.unit}
- Property Type: ${landContext.propertyType}
- Zoning: ${landContext.zoning}
- Topography: ${landContext.topography}
- Utilities: Electric (${landContext.hasElectricity}), Water (${landContext.hasWater}), Sewer (${landContext.hasSewer})`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: systemContext,
        temperature: 0.7,
      }
    });

    return res.json({
      reply: response.text || 'No response generated.'
    });

  } catch (err: any) {
    console.error('Error in /api/land-advisor:', err);
    return res.status(500).json({ error: err.message || 'Error processing AI question' });
  }
});

// Vite Development or Static Production middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TerraVal server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
